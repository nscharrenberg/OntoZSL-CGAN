from .deepwalk.model import DeepWalk
from .node2vec.model import Node2Vec
from .factory import walker_factory
