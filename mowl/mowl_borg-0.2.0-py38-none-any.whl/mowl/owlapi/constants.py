MOWL_IRI = "http://cbrc.kaust.edu.sa/mowl"
R = f"{MOWL_IRI}#relation"
THING = f"{MOWL_IRI}#Thing"
INDIVIDUAL = f"{MOWL_IRI}#Individual"
