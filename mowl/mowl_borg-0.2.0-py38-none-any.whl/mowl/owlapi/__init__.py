from mowl.owlapi.adapter import OWLAPIAdapter
from mowl.owlapi.model import (
    OWLOntology, OWLClass, OWLObjectProperty, OWLSubClassOfAxiom,
    OWLEquivalentClassesAxiom, OWLObjectSomeValuesFrom, ClassExpressionType,
    Imports, OWLAxiom, OWLDisjointClassesAxiom, OWLNaryAxiom, OWLClassAssertionAxiom,
    OWLObjectPropertyAssertionAxiom
)
