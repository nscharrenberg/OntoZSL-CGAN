from org.semanticweb.owlapi.model import (
    OWLOntology, OWLClass, OWLObjectProperty, OWLSubClassOfAxiom,
    OWLEquivalentClassesAxiom, OWLObjectSomeValuesFrom, ClassExpressionType,
    OWLAxiom, OWLDisjointClassesAxiom, OWLNaryAxiom,
    OWLObjectPropertyAssertionAxiom, OWLClassAssertionAxiom)

from org.semanticweb.owlapi.model.parameters import Imports
