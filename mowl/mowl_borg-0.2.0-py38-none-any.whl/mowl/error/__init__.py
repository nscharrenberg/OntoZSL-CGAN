"""Init module"""
from mowl.error.messages import OWLAPI_DIRECT, INVALID_WALKER_NAME, \
    EMBEDDINGS_NOT_FOUND_MODEL_NOT_TRAINED
