from .model import KGEModel
